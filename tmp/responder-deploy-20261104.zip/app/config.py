import os
from dataclasses import dataclass, field

from dotenv import load_dotenv

load_dotenv()


def _bool(name: str, default: bool) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


def _int_list(name: str, default: str) -> tuple[int, ...]:
    """Comma-separated int list env var, e.g. FOLLOWUP_WAIT_DAYS=3,4,6,8.
    A single value (the old scalar form) still works and behaves as before."""
    raw = os.getenv(name, default)
    vals = tuple(int(part.strip()) for part in raw.split(",") if part.strip())
    return vals or tuple(int(part.strip()) for part in default.split(","))


def _str_list(name: str, default: str = "") -> tuple[str, ...]:
    return tuple(
        part.strip().upper()
        for part in os.getenv(name, default).split(",")
        if part.strip()
    )


@dataclass
class Settings:
    smartlead_api_key: str = os.getenv("SMARTLEAD_API_KEY", "")
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")
    app_password: str = os.getenv("APP_PASSWORD", "")
    secret_key: str = os.getenv("SECRET_KEY", "dev-secret-change-me")
    n8n_webhook_url: str = os.getenv("N8N_WEBHOOK_URL", "")
    smartlead_webhook_secret: str = os.getenv("SMARTLEAD_WEBHOOK_SECRET", "")
    public_base_url: str = os.getenv("PUBLIC_BASE_URL", "http://localhost:8080")

    db_path: str = os.getenv("DB_PATH", "/data/responder.db")
    # Draft images live beside the DB, on the same Docker volume.
    upload_dir: str = os.getenv("UPLOAD_DIR", "/data/uploads")

    dry_run: bool = field(default_factory=lambda: _bool("DRY_RUN", True))
    auto_send_followups: bool = field(
        default_factory=lambda: _bool("AUTO_SEND_FOLLOWUPS", False)
    )
    # After the daily scan, pre-generate every due follow-up draft in one
    # Anthropic Batch API job (50% token discount, results within ~1h) so the
    # morning dashboard is a ready review queue. Generation only — sending
    # still always requires a click (unless AUTO_SEND_FOLLOWUPS is also on).
    # Approved on-by-default by Andrew, 2026-07-19.
    auto_generate_followups: bool = field(
        default_factory=lambda: _bool("AUTO_GENERATE_FOLLOWUPS", True)
    )

    interested_category_name: str = os.getenv(
        "INTERESTED_CATEGORY_NAME", "Interested"
    )
    autoreply_category_name: str = os.getenv(
        "AUTOREPLY_CATEGORY_NAME", "Auto-Reply"
    )
    # Smartlead's own category names. These are mirrored into the dashboard;
    # probabilistic reply-classifier verdicts never write them back remotely.
    not_interested_category_name: str = os.getenv(
        "NOT_INTERESTED_CATEGORY_NAME", "Not Interested"
    )
    # Review negative replies in the inbox without changing Smartlead's label.
    show_not_interested_leads: bool = field(
        default_factory=lambda: _bool("SHOW_NOT_INTERESTED_LEADS", False)
    )
    do_not_contact_category_name: str = os.getenv(
        "DO_NOT_CONTACT_CATEGORY_NAME", "Do Not Contact"
    )
    # "Wrong Person" remains distinct from Auto-Reply for local workflow: an
    # out-of-office reader is coming back, while this mailbox never will.
    wrong_person_category_name: str = os.getenv(
        "WRONG_PERSON_CATEGORY_NAME", "Wrong Person"
    )
    # Smartlead's own "meeting booked" lead category — the app's success
    # signal. Matched case/punctuation-insensitively (the real account has it
    # as "Meeting-Booked"), so "Meeting booked" etc. also resolve.
    meeting_booked_category_name: str = os.getenv(
        "MEETING_BOOKED_CATEGORY_NAME", "Meeting-Booked"
    )
    # Days to wait before follow-up #N — indexed by how many follow-ups have
    # already gone out (last value repeats past the end of the list). A single
    # number keeps the old fixed cadence; "3,4,6,8" spaces touches further
    # apart as the thread goes colder.
    followup_wait_days: tuple[int, ...] = field(
        default_factory=lambda: _int_list("FOLLOWUP_WAIT_DAYS", "3")
    )
    # A lead rated 🔥 very hot (app/lead_temperature.py — they asked to meet,
    # call or see a demo) is chased on this many HOURS instead of the day-based
    # cadence above. Only ever shortens the wait, never lengthens it. 0 turns
    # the short cadence off and puts hot leads back on FOLLOWUP_WAIT_DAYS; they
    # still sort to the top of the inbox either way.
    hot_followup_wait_hours: int = int(os.getenv("HOT_FOLLOWUP_WAIT_HOURS", "24"))
    # When true, the follow-up wait in days skips Saturdays and Sundays.
    followup_business_days: bool = os.getenv("FOLLOWUP_BUSINESS_DAYS", "false").lower() == "true"
    max_followups: int = int(os.getenv("MAX_FOLLOWUPS", "4"))
    # Where a lead is assumed to be when neither the sequence nor the campaign
    # name says otherwise (thread_utils.guess_timezone). Decides the morning
    # send window for scheduled follow-ups and subsequence steps, so OneBodyLDN
    # sets Europe/London; blank keeps the old Europe/Zagreb default.
    default_lead_timezone: str = os.getenv("DEFAULT_LEAD_TIMEZONE", "").strip()
    # After the follow-up cap is hit, quietly resurface the lead for one
    # revival touch once this many days pass with no reply. 0 disables.
    revive_after_days: int = int(os.getenv("REVIVE_AFTER_DAYS", "60"))
    daily_scan_hour_utc: int = int(os.getenv("DAILY_SCAN_HOUR_UTC", "6"))
    # Minutes in which the lightweight reply catcher must complete one sweep of
    # every active campaign. The scheduler runs once a minute and rotates only
    # the oldest fraction each tick, avoiding the old one-call-per-campaign
    # burst while preserving the same worst-case fallback delay. 0 disables.
    scan_interval_minutes: int = int(os.getenv("SCAN_INTERVAL_MINUTES", "5"))

    # How often to ask Smartlead "who has written to us lately?" — the poll that
    # decides how long a lead's FIRST reply stays invisible
    # (scheduler.run_new_reply_poll). Two API calls and no per-lead work, so it
    # runs far more often than the reply-catch pass above. 0 disables.
    new_reply_poll_seconds: int = int(os.getenv("NEW_REPLY_POLL_SECONDS", "60"))

    # Keep enough headroom for Smartlead calls made by n8n or a human using
    # another integration with the same key. Both limits apply per process and
    # per API key; the server's 429 Retry-After remains authoritative.
    smartlead_requests_per_minute: int = int(
        os.getenv("SMARTLEAD_REQUESTS_PER_MINUTE", "50")
    )
    smartlead_burst_per_second: int = int(
        os.getenv("SMARTLEAD_BURST_PER_SECOND", "8")
    )
    smartlead_category_cache_seconds: int = int(
        os.getenv("SMARTLEAD_CATEGORY_CACHE_SECONDS", "600")
    )

    # Deliverability health (app/deliverability_health.py). Monitoring is
    # read-only by default; changing a mailbox in Smartlead additionally needs
    # DELIVERABILITY_AUTO_APPLY=true and DRY_RUN=false.
    deliverability_health_enabled: bool = field(
        default_factory=lambda: _bool("DELIVERABILITY_HEALTH_ENABLED", True)
    )
    deliverability_auto_apply: bool = field(
        default_factory=lambda: _bool("DELIVERABILITY_AUTO_APPLY", False)
    )
    mailbox_health_check_hours: int = int(
        os.getenv("MAILBOX_HEALTH_CHECK_HOURS", "24")
    )
    domain_blacklist_check_hours: int = int(
        os.getenv("DOMAIN_BLACKLIST_CHECK_HOURS", "24")
    )
    mailbox_rehab_threshold: int = int(
        os.getenv("MAILBOX_REHAB_THRESHOLD", "90")
    )
    mailbox_phase_stable_days: int = int(
        os.getenv("MAILBOX_PHASE_STABLE_DAYS", "5")
    )
    # Weekly inbox-placement tests (app/placement.py, Smartlead SmartDelivery).
    # Off by default: every run spends placement credits. A mailbox whose latest
    # test lands under PLACEMENT_INBOX_THRESHOLD % in the inbox is held in rehab
    # and taken out of active campaigns (the latter only with auto-apply on and
    # DRY_RUN=false).
    placement_tests_enabled: bool = field(
        default_factory=lambda: _bool("PLACEMENT_TESTS_ENABLED", False)
    )
    placement_inbox_threshold: int = int(os.getenv("PLACEMENT_INBOX_THRESHOLD", "90"))
    placement_weekday: str = os.getenv("PLACEMENT_WEEKDAY", "sat")
    placement_hour_utc: int = int(os.getenv("PLACEMENT_HOUR_UTC", "6"))
    placement_collect_hours: int = int(os.getenv("PLACEMENT_COLLECT_HOURS", "6"))
    # Campaign whose step-1 copy a mailbox is tested with when it is attached
    # there; 0 = each mailbox's own newest active campaign.
    placement_campaign_id: int = int(os.getenv("PLACEMENT_CAMPAIGN_ID", "0"))
    # Comma-separated sending domains the Health tab must never change or test,
    # e.g. a client's own mailboxes that happen to sit on this Smartlead account.
    health_exclude_domains: str = os.getenv("HEALTH_EXCLUDE_DOMAINS", "")
    # Optional APIVoid Domain Reputation API. Without a key the app still
    # checks MX/SPF/DMARC and labels blacklist coverage as not configured.
    apivoid_api_key: str = os.getenv("APIVOID_API_KEY", "")
    deliverability_alert_webhook_url: str = os.getenv(
        "DELIVERABILITY_ALERT_WEBHOOK_URL", ""
    )

    # Which model sorts an incoming reply into "real prospect" vs "out of office
    # / rejection" (app/reply_classifier.py), deciding whether to spend a draft
    # on it, and separately rates how hot the lead is (app/lead_temperature.py).
    # One word in, one word out — so the default is the cheapest model in the
    # picker. Each message is only ever judged once (db.sort_replied_lead /
    # category_message_id): the verdict is sticky until either a new message
    # arrives or Andrew changes the status by hand, never re-decided by a later
    # pass over the same content. Overridable per-install here and, at
    # runtime, from the dashboard's Models panel ("Sorting incoming replies").
    reply_classifier_model: str = os.getenv(
        "REPLY_CLASSIFIER_MODEL", "deepseek/deepseek-v4-flash"
    )

    # Detect the lead's language from their reply when Smartlead has no
    # "Language Code" custom field. That is a Claude call per lead during the
    # scan, so an English-only client (AeroDefense) should turn it off: it saves
    # tens of thousands of calls and makes the scan work even with no Anthropic
    # credit, since the scan then needs no model at all.
    detect_language: bool = field(
        default_factory=lambda: _bool("DETECT_LANGUAGE", True)
    )

    # Skip leads whose last outbound message came from a mailbox Smartlead no
    # longer returns — the mailbox is retired, so the thread can't be replied
    # to. AeroDefense needs this; Mindaptive's mailboxes are all live and its
    # personas resolve by name hint, so it stays off by default.
    require_known_sender: bool = field(
        default_factory=lambda: _bool("REQUIRE_KNOWN_SENDER", False)
    )

    anthropic_model: str = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5")
    anthropic_translate_model: str = os.getenv(
        "ANTHROPIC_TRANSLATE_MODEL", "claude-haiku-4-5"
    )

    # OpenRouter — a second model provider for draft writing. Set the key and
    # every OpenRouter model in app/models_registry.py shows up in the
    # dashboard's model picker alongside the Anthropic ones (labelled by
    # provider, with live per-million-token prices pulled from OpenRouter's own
    # /models endpoint). Leave blank and the picker is Anthropic-only.
    openrouter_api_key: str = os.getenv("OPENROUTER_API_KEY", "")
    # Extra OpenRouter model ids to offer, comma-separated (e.g.
    # "qwen/qwen3.7-plus,mistralai/mistral-medium-3-5"). Added on top of the
    # curated list in models_registry.CURATED_OPENROUTER_MODELS, so a new model
    # can be tried without a code change.
    openrouter_extra_models: str = os.getenv("OPENROUTER_MODELS", "")

    calendly_link: str = os.getenv(
        "CALENDLY_LINK", "https://calendly.com/andrew-mindaptive/30min"
    )
    # Direct Calendly -> responder booking webhook. These stay blank for every
    # non-Mindaptive container, so /webhooks/calendly is disabled there.
    calendly_webhook_signing_key: str = os.getenv(
        "CALENDLY_WEBHOOK_SIGNING_KEY", ""
    )
    # Optional comma-separated allowlist of event type URIs. Blank accepts every
    # event type on the account: a single URI silently dropped bookings made on
    # any other link Andrew's team sends (e.g. /website-redesign).
    calendly_event_type_uri: str = os.getenv("CALENDLY_EVENT_TYPE_URI", "")

    # Google Sheets — the "Export for LinkedIn" button (app/exports/sheet_export.py).
    # OAuth rather than a service account: Andrew already owns both spreadsheets,
    # so acting as him needs nothing shared and no key file placed on the droplet.
    google_client_id: str = os.getenv("GOOGLE_CLIENT_ID", "")
    google_client_secret: str = os.getenv("GOOGLE_CLIENT_SECRET", "")
    # Optional. The refresh token normally lives in app_settings (obtained via
    # the dashboard's Connect flow), but the two containers have separate
    # databases — setting this in .env.aerodefense lets the second one reuse the
    # consent the first already gave instead of doing its own round trip.
    google_refresh_token: str = os.getenv("GOOGLE_REFRESH_TOKEN", "")
    # Spreadsheet this client's leads are exported into, one tab per sending
    # persona. Per client, so it belongs in each .env. Blank hides the button.
    linkedin_sheet_id: str = os.getenv("LINKEDIN_SHEET_ID", "")
    # Where a lead goes when its thread was sent from a mailbox that no longer
    # maps to a persona (AeroDefense's retired anna@/linda@/lexi.r@ inboxes).
    # Created with a header row if the spreadsheet doesn't have it.
    linkedin_sheet_fallback_tab: str = os.getenv("LINKEDIN_SHEET_FALLBACK_TAB", "Other")

    # Optional automatic worklist (app/interested_sheet.py): every lead that
    # clears reply_classifier as INTERESTED gets a row here the moment it
    # happens, no click required — unlike the LinkedIn sheet above, which is
    # per-lead and manual. Blank (the default) means the module no-ops.
    # Reuses the same Google OAuth connection as the LinkedIn export.
    interested_sheet_id: str = os.getenv("INTERESTED_SHEET_ID", "")

    # Shared secret for POST /webhooks/booking-confirmed (app/webhook.py) — an
    # external automation (e.g. an n8n flow watching a booking-confirmation
    # inbox) calls this to record a meeting booked outside Smartlead's own
    # category flow. Same header/query-param convention as
    # SMARTLEAD_WEBHOOK_SECRET. Blank disables the route's secret check, which
    # is fine for local testing but should always be set once this is public.
    booking_webhook_secret: str = os.getenv("BOOKING_WEBHOOK_SECRET", "")
    # Bearer token for POST /api/prospect-contacts (app/prospect_contacts.py):
    # WebsiteGenerator's cli/contacts.mjs pushes the WhatsApp/phone/email/social
    # contacts it scraped from a prospect's site. Blank disables the route.
    contact_ingest_token: str = os.getenv("CONTACT_INGEST_TOKEN", "")
    # Codes that prove a booking came through this client's offer. An exact
    # email match never needs one; name fallback is disabled unless the booking
    # carries one of these codes.
    booking_match_codes: tuple[str, ...] = field(
        default_factory=lambda: _str_list("BOOKING_MATCH_CODES")
    )


settings = Settings()
